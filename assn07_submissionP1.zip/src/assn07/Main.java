package assn07;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> passwordManager = new PasswordManager<>();

        // your code below

        passwordManager.put("youtube", "secure123");
        passwordManager.put("linkedin", "jobhunt456");

        System.out.println(passwordManager.get("youtube")); // Expected: secure123
        System.out.println(passwordManager.get("linkedin")); // Expected: jobhunt456

        System.out.println(passwordManager.size()); // Expected: 2

        passwordManager.put("github", "password123");
        passwordManager.put("youtube", "password123"); // Updates "youtube" password
        System.out.println(passwordManager.checkDuplicates("password123")); // Expected: [github, youtube]

        passwordManager.put("email", "mypassword");
        passwordManager.remove("email");
        System.out.println(passwordManager.get("email")); // Expected: null

        passwordManager.put("snapchat", "snap123");
        passwordManager.put("snapchat", "newsnap123"); // Overwriting password
        System.out.println(passwordManager.get("snapchat")); // Expected: newsnap123

        System.out.println(passwordManager.keySet()); // Expected: [youtube, linkedin, github, snapchat]


        // infite loop to go back to "Enter master password"
        System.out.println("Enter Master Password:");
        while (true) {
            String enteredPassword = scanner.nextLine().trim();
            if (passwordManager.checkMasterPassword(enteredPassword)) {
                break;
            }
            System.out.println("Enter Master Password:"); // Repeat until correct
        }

        // loop to read and execute commands until "Exit" is entered
        while (true) {
            System.out.println("Enter a command:");
            String command = scanner.nextLine().trim();

            switch (command) {
                case "New password": {
                    System.out.println("Enter website:");
                    String website = scanner.nextLine().trim();
                    System.out.println("Enter password:");
                    String password = scanner.nextLine().trim();
                    passwordManager.put(website, password);
                    System.out.println("New password added");
                    break;
                }

                case "Get password": {
                    System.out.println("Enter website:");
                    String website = scanner.nextLine().trim();
                    String retrievedPassword = passwordManager.get(website);
                    if (retrievedPassword == null) {
                        System.out.println("Account does not exist");
                    } else {
                        System.out.println(retrievedPassword);
                    }
                    break;
                }

                case "Delete account": {
                    System.out.println("Enter website:");
                    String website = scanner.nextLine().trim();
                    String removedPassword = passwordManager.remove(website);
                    if (removedPassword == null) {
                        System.out.println("Account does not exist");
                    } else {
                        System.out.println("Account deleted");
                    }
                    break;
                }

                case "Check duplicate password": {
                    System.out.println("Enter password:");
                    String password = scanner.nextLine().trim();
                    List<String> duplicates = passwordManager.checkDuplicates(password);
                    if (duplicates.isEmpty()) {
                        System.out.println("No account uses that password");
                    } else {
                        System.out.println("Websites using that password:");
                        for (String website : duplicates) {
                            System.out.println(website);
                        }
                    }
                    break;
                }

                case "Get accounts": {
                    System.out.println("Your accounts:");
                    for (String website : passwordManager.keySet()) {
                        System.out.println(website);
                    }
                    break;
                }

                case "Generate random password": {
                    System.out.println("Enter password length:");
                    int length = Integer.parseInt(scanner.nextLine().trim());
                    if (length < 4) {
                        length = 4; // Ensure minimum length
                    }
                    String randomPassword = passwordManager.generatesafeRandomPassword(length);
                    System.out.println("Generated password: " + randomPassword);
                    break;
                }

                case "Exit":
                    System.out.println("Goodbye!");
                    return; // Exit the program

                default:
                    System.out.println("Command not found");
            }
        }
    }
}


